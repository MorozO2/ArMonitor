package com.example.armonitor

import android.app.Activity
import android.os.Bundle

class ArActivity : Activity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
    }
}