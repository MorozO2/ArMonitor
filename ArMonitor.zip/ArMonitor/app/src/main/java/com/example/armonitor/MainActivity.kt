package com.example.armonitor

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.eclipse.paho.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.*
import kotlin.Throws

class MainActivity : AppCompatActivity() {
    private var toAr: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toAr = findViewById(R.id.toAr)
        toAr.setOnClickListener(View.OnClickListener
        //BUTTON FOR OPENING AR ACTIVITY
        { openArActivity() })
        val topic = "topic/testing"
        val qos = 1
        val clientId = MqttClient.generateClientId()
        val client = MqttAndroidClient(this.applicationContext, "tcp://10.202.50.40:1883",
                clientId)
        MqttConnectSub(client, topic, qos)
        client.setCallback(object : MqttCallback {
            override fun connectionLost(cause: Throwable) {
                Log.d(TAG, "Connection lost")
            }

            @Throws(Exception::class)
            override fun messageArrived(topic: String, message: MqttMessage) {
                val payload = message.toString()
                Log.d(TAG, payload)
                Toast.makeText(applicationContext, payload, payload.length).show()
                DisplayMessage(payload)
            }

            override fun deliveryComplete(token: IMqttDeliveryToken) {
                Log.d(TAG, "Delivery complete")
            }
        })
    }

    ///METHOD FOR OPENING AR ACTIVITY//////////////////////////////////////////
    private fun openArActivity() {
        val openArView = Intent(this, ArActivity::class.java)
        startActivity(openArView)
    }

    ///METHOD FOR OPENING AR ACTIVITY/*/////////////////////////////////////////
    ///METHOD FOR DISPLAYING ACTIVITY AS TEXTVIEW//////////////////////////////////////////
    private fun DisplayMessage(msg: String) {
        val ll = findViewById<View>(R.id.receivedLayout) as LinearLayout
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(ViewGroup.LayoutParams.MATCH_PARENT, 10, ViewGroup.LayoutParams.MATCH_PARENT, 10)
        val mqttMsg = TextView(applicationContext)
        mqttMsg.layoutParams = params
        mqttMsg.setBackgroundColor(resources.getColor(R.color.lime))
        mqttMsg.gravity = Gravity.CENTER or Gravity.BOTTOM
        mqttMsg.text = msg
        ll.addView(mqttMsg)
    }

    ///METHOD FOR OPENING AR ACTIVITY/*/////////////////////////////////////////
    private fun MqttConnectSub(client: MqttAndroidClient, topic: String, qos: Int) {
        //CONNECT MQTT////////////////////////////////////////////////////////////////////////////////////////////
        try {
            val token = client.connect()
            token.actionCallback = object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken) {
                    // We are connected
                    Log.d(TAG, "onSuccess")

                    //SUBSCRIBE TO MQTT TOPIC: MUST BE INSIDE THE onSuccess() method after client.connect()//////////////////
                    try {
                        val subToken = client.subscribe(topic, qos)
                        subToken.actionCallback = object : IMqttActionListener {
                            override fun onSuccess(asyncActionToken: IMqttToken) {
                                // The message was published
                                Log.d(TAG, "Subscribed")
                            }

                            override fun onFailure(asyncActionToken: IMqttToken,
                                                   exception: Throwable) {
                                // The subscription could not be performed, maybe the user was not
                                // authorized to subscribe on the specified topic e.g. using wildcards
                                Log.d(TAG, "Subscribe failed")
                            }
                        }
                    } catch (e: MqttException) {
                        e.printStackTrace()
                    }
                    //SUBSCRIBE*/////////////////////////////////////////////////////////////////
                }

                override fun onFailure(asyncActionToken: IMqttToken, exception: Throwable) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Log.d(TAG, "onFailure")
                }
            }
        } catch (e: MqttException) {
            e.printStackTrace()
        }
        //CONNECT*////////////////////////////////////////////////////////////////////////////////
    }

    companion object {
        private val TAG = MainActivity::class.java.simpleName
    }
}